# Regresjonslinje og utregninger for hele lista
lengder = read.csv("terningdropp57.csv", sep=",")
lengder
table1 <- data.frame(lengder$lengde,lengder$hoyde)
library(ggplot2)

x = lengder$Hoyde
y = lengder$Lengde

#plotting av tabell og regresjonslinje
linearModel = lm(lengder$Lengde ~ lengder$Hoyde)

regression_line <- lm( y~x, data=table1)

plot(x,y, xlab = 'starthoyde', ylab='lengde')
abline(regression_line)

modelSummary = summary(linearModel)
modelSummary

Beta = modelSummary$coefficients[1:2] #dette viser koifisentene for regresjonslinjen

modelSummary$residuals
SSe = sum(modelSummary$residuals^2) #dette viser kvadratsummen av residualene
Se = sqrt(SSe/20-2) #dette viser standardfeil




#Oppgave 2b, finne regresjonslinje for 5 f??rste
col1 = c(10,10,15,20,25) #Starth??yde
col2 = c(36,29,46,74,79) #Lengde

table2 <- data.frame(col1,col2)
library(ggplot2)

regression_line <- lm(col2 ~col1, data=table1)

plot(col1,col2, xlab = 'starthoyde', ylab='lengde')
abline(regression_line)

lm(col2~ col1)