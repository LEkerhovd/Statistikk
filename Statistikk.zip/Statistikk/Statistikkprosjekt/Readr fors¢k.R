library(readr)

list_of_files <- list.files(path = "C:/Users/User/Documents/RStudio/Statistikkprosjekt",
                            recursive = TRUE,
                            pattern = "\\.csv$",
                            full.names = TRUE)

df <- readr::read_csv(list_of_files, id = "file_name")
df