
# Using tidyverse
library(tidyverse)
df <-
  list.files(path = "C:/Users/User/Documents/RStudio/Statistikkprosjekt", pattern = "*.csv") %>% 
  map_df(~read_csv(.))
df

