library(data.table)
library(ggplot2)
library(extraDistr)
#Bruker f??lgende kode for ?? sl?? sammen .csv filer
df <- 
  list.files(path = "C:/Users/User/Documents/RStudio/Statistikkprosjekt", pattern = "*.csv") %>% 
map_df(~fread(.))
df

#fjerner rader som ikke har noen verdier
df2 <- df[-(148:153),]
df2


data <- df2
print(data)

#Velger Jeffreys prior for "Ordinary Ignorance"
u=0.5


#Setter 90% kredibilitetsintervall for fremgang i prosjektet ved intervallestimat
alpha1 = 0.05
alpha2 = 0.95

#Setter signifikans ??=0.1 for fremgang i prosjektet ved hypotesetesting
alfa=0.1

#Skudd fra ca. 5 meter
Meter5 <- glm(skudd1 ~ avstand1, family=binomial,data = df)
Meter5

#f??rer lengden p?? tabellen, antall skudd per fors??k
n = length(data$skudd1)


# f??rer positive og negative resultater
a1 = sum(data$skudd1 == 1)
b1 = sum(data$skudd1 == 0)

# Skriver opp antall positive og negative fors??k
print(paste("For n =", n, "positive resultater", a1, "negative resultater", b1))

#finner p1
p1=a1/(a1+b1)

#Hypotesetesting ved 5 meter
H_01 = 1-pbeta(p1,a1,b1)
H_01
cat("Forkaster ikke H0, 0.1 <", H_01)

#Intervallestimat for 5 meter
#Nedre grense ved 5 meter
L1=qbeta(alpha1,a1,b1)
#??vre grense ved 5 meter
U1=qbeta(alpha2,a1,b1)

#Normaltiln??rming ved 5 meter
#P(Z<0)
mu1=a1/(a1+b1)
sigma1=sqrt((a1*b1)/((a1+b1)^2 +(a1+b1+1)))
#Nedre
l1=qbeta(alpha1,mu1,sigma1)
#??vre
u1=qbeta(alpha2,mu1,sigma1)
  
#Prediktivt 5 meter
#sannsynlighet for x antall m??l for de neste 20 skudd
N1=20 #Antall skudd
A1=a1+u
B1=b1+u
X1=0:20
y1=dbbinom(X1,N1,A1,B1)
plot(X1,y1,type="h",lwd="4",col="blue")
#Sannsynlighet for x antall skudd f??r de neste 10 m??l
N2=10
X2=0:30
y2=dbnbinom(X2,N2,A1,B1)
plot(X2,y2,type="h",lwd="4",col="blue")


#Skudd fra ca. 8 meter
Meter8 <- glm(skudd2 ~ avstand2, family=binomial,data = df)
Meter8


# f??rer positive og negative resultater
a2 = sum(data$skudd2 == 1)
b2 = sum(data$skudd2 == 0)

# Skriver opp antall positive og negative fors??k
print(paste("For n =", n, "positive resultater", a2, "negative resultater", b2))

#finner p2
p2=a2/(a2+b2)

#Hypotesetesting ved 8 meter
H_02 = 1-pbeta(p2,a2,b2)
H_02
cat("Forkaster ikke H0, 0.1 <", H_02)

#Intervallestimat for 8 meter
#Nedre grense ved 8 meter
L2=qbeta(alpha1,a2,b2)
#??vre grense ved 8 meter
U2=qbeta(alpha2,a2,b2)
\
#Normaltiln??rming ved 8 meter
#P(Z<0)
mu2=a2/(a2+b2)
sigma2=sqrt((a2*b2)/((a2+b2)^2 +(a2+b2+1)))
#Nedre
l2=qbeta(alpha1,mu2,sigma2)
#??vre
u2=qbeta(alpha2,mu2,sigma2)

#Prediktivt 8 meter
#sannsynlighet for x antall m??l for de neste 20 skudd
N3=20 #Antall skudd
A3=a2+u
B3=b2+u
X3=0:20
y3=dbbinom(X3,N3,A3,B3)
plot(X3,y3,type="h",lwd="4",col="blue")
#Sannsynlighet for x antall skudd f??r de neste 10 m??l
N4=10
X4=0:40
y4=dbnbinom(X4,N4,A3,B3)
plot(X4,y4,type="h",lwd="4",col="blue")

#Sammenligning av parametere for 5 og 8 meter
mu=mu1-mu2
sigma=sigma1-sigma2
H_0=pnorm(mu,sigma)
cat("Forkaster ikke H0, 0.1 <", H_0)

#F??rste skudd fra ca. 10 meter
Meter10 <- glm(skudd3 ~ avstand3, family=binomial,data = df)
Meter10

# f??rer positive og negative resultater
a3 = sum(data$skudd3 == 1)
b3 = sum(data$skudd3 == 0)

# Skriver opp antall positive og negative fors??k
print(paste("For n =", n, "positive resultater", a3, "negative resultater", b3))

#finner p3
p3=a3/(a3+b3)

#Hypotesetesting ved 10 meter
H_03 = 1-pbeta(p3,a3,b3)
H_03
cat("Forkaster ikke H0, 0.1 <", H_03)

#Intervallestimat for 10 meter
#Nedre grense ved f??rste skudd fra 10 meter
L3=qbeta(alpha1,a3,b3)
#??vre grense ved f??rste skudd fra 10 meter
U3=qbeta(alpha2,a3,b3)

#Normaltiln??rming ved 10 meter
#P(Z<0)
mu3=a3/(a3+b3)
sigma3=sqrt((a3*b3)/((a3+b3)^2 +(a3+b3+1)))
#Nedre
l3=qbeta(alpha1,mu3,sigma3)
#??vre
u3=qbeta(alpha2,mu3,sigma3)

#Andre skudd fra 10 meter
Meter10_2 <- glm(skudd4 ~ avstand3, family=binomial,data = df)
Meter10_2

# f??rer positive og negative resultater
a4 = sum(data$skudd4 == 1)
b4 = sum(data$skudd4 == 0)

#finner p4
p4=a4/(a4+b4)

#Alle skudd fra 10 meter
n2=n*2
a5=a3+a4
b5=b3+b4
p5=a5/(a5+b5)

#Prediktivt 10 meter
#sannsynlighet for x antall m??l for de neste 20 skudd
N5=20 #Antall skudd
A5=a5+u
B5=b5+u
X5=0:20
y5=dbbinom(X5,N5,A5,B5)
plot(X5,y5,type="h",lwd="4",col="blue")
#Sannsynlighet for x antall skudd f??r de neste 10 m??l
N6=10
X6=0:40
y6=dbnbinom(X6,N6,A5,B5)
plot(X6,y6,type="h",lwd="4",col="blue")


# Skriver opp antall positive og negative fors??k
print(paste("For n =", n, "positive resultater", a4, "negative resultater", b4))

#Betafordeling PDF ved 5 meter
x1=seq(0,1,0.001)
Beta5_pdf=dbeta(x1,a1,b1)
plot(Beta5_pdf,type="l",col="blue",lwd=3)

#Betafordeling CDF ved 5 meter
Beta5_CDF=pbeta(x1,a1,b1)
plot(Beta5_CDF,type="l",col="red",lwd=3)

#Betabinomiskfordeling PDF ved 5 meter
x2=0:n
BetaBin5_pdf=dbbinom(x2,n,a1,b1)
plot(BetaBin5_pdf,type="l",col="purple",lwd=3)

#Betafordeling PDF ved 8 meter
x1=seq(0,1,0.001)
Beta8_pdf=dbeta(x1,a2,b2)
plot(Beta8_pdf,type="l",col="blue",lwd=3)

#Betafordeling CDF ved 8 meter
Beta8_CDF=pbeta(x1,a2,b2)
plot(Beta8_CDF,type="l",col="red",lwd=3)

#Betabinomiskfordeling PDF ved 8 meter
x2=0:n
BetaBin8_pdf=dbbinom(x2,n,a2,b2)
plot(BetaBin8_pdf,type="l",col="purple",lwd=3)

#Betafordeling PDF ved 10 meter
x1=seq(0,1,0.001)
Beta10_pdf=dbeta(x1,a3,b3)
plot(Beta10_pdf,type="l",col="blue",lwd=3)

#Betafordeling CDF ved 10 meter
Beta10_CDF=pbeta(x1,a3,b3)
plot(Beta10_CDF,type="l",col="red",lwd=3)

#Betabinomiskfordeling PDF ved 10 meter
x2=0:n
BetaBin10_pdf=dbbinom(x2,n,a3,b3)
plot(BetaBin10_pdf,type="l",col="purple",lwd=3)


#Kode for beste avstand ved riktig loggf??ring
#her ville alle skuddene v??rt f??rt i en kolonne, og alle avstandene i en kolonne
skuddMod <- glm(skudd ~ avstand, family=binomial,data = df)
#henter koeffisienter fra modellen
koeffisienter <- coef(skuddMod)
#bruker funksjon for ?? finne sannsynlighet for m??l ved gitt distanse
beregnet_sann <- function(koeffisienter, avstand) {
  intercept <- koeffisienter[1]#intercept og slope er navn ofte brukt for koeffisientene for y og x akse
  slope <- koeffisienter[2]
  logit <- intercept + slope*avstand
  sannsynlighet <- 1/(1+exp(-logit))
  return(sannsynlighet)
}
#lager funksjon for ?? regne ut odds
beregnet_odds <- function(koeffisienter,avstand){
  sannsynlighet <- beregnet_sann(koeffisienter,avstand)
  odds <- (1-sannsynlighet)/sannsynlighet
  return(odds)
}