2+2
a=2+2
a
(b=3+4)

liste = c(1,2,3,5,7,11)
rekke = c(64,32,16,8,4,2)
liste
rekke

(lavMatrise = rbind(liste,rekke))
lavMatrise[2,4]
lavMatrise[2,]
lavMatrise[,4]

(hoyMatrise = cbind(liste,rekke))
hoyMatrise[5,1]
(hoyDataRamme = as.data.frame(hoyMatrise))
hoyDataRamme$liste
hoyDataRamme[,1]
hoyDataRamme[4,]

plot(x=liste,y=rekke)
plot(x=liste,y=rekke,col="maroon")
plot(x=liste,y=rekke,col="maroon",type="h")
plot(x=liste,y=rekke,col="maroon",type="l")
plot(x=liste,y=rekke,col="maroon",type="s")
plot(x=liste,y=rekke,col="maroon",type="p")
plot(x=liste,y=rekke,col="maroon",type="p",pch=5)
plot(x=liste,y=rekke,col="maroon",type="p",cex=5)

liste2=c(3,7,9)
rekke2=c(42,11,23)
lines(x=liste2,y=rekke2,type="l",col="blue"). # Legger til på plott

plot(hoyDataRamme) # Forenklet
abline(v=6,col="green")
abline(h=50,col="pink")

?plot

# install.packages("car")
library(car)
scatterplot(x=liste,y=rekke)

sample(82,5)
høyder = read.csv("Høyde og arv.csv", sep=";")
