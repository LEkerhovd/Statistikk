prior1_valgavTerning = c(1/2,1/2) #Sannsynelighet for D9 og D6
likelihood__sannsForUtfall = c(1/9,1/6) # sanns. for 2 på hver av terningene
(samsannsynelighet = prior1_valgavTerning * likelihood__sannsForUtfall)
(totalSannsynelighet1=sum(samsannsynelighet))
(posterior1=samsannsynelighet/totalSannsynelighet1)

a=2+2
(b=3*3)

install.packages("car")
install.packages("ggplot2")







rm(list = ls())
