
col1 = c(10,10,15,20,25)
col2 = c(36,29,46,74,79)
table1 <- data.frame(col1, col2)

library(ggplot2)


regression_line <- lm(col2 ~ col1, data = table1)

plot(col1, col2, data = table1, xlab = 'Fallhøyde', ylab = 'Lengde')
abline(regression_line)

col3 = c(10,10,10,10,10,15,15,15,15,15,20,20,20,20,20,25,25,25,25,25)
col4 = c(36,29,27,38,25,46,49,54,49,44,52,74,57,62,71,77,63,81,73,79)
table2 <- data.frame(col3,col4)

regression_line <- lm(col4 ~ col3, data = table2)

plot(col1, col2, data = table1, xlab = 'Fallhøyde', ylab = 'Lengde')
abline(regression_line)

