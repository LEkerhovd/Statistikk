n = 60
topp = 9
x = rnorm(n,topp,3)
p = exp(-0.1*(topp-x)^2)
y = rep(0,n)
for (k in 1:n) {
  y[k] = rbinom(1,1,p[k])
}
logMod = glm(y ~ x + I(x^2), family=binomial)
summary(logMod)
a = logMod$coefficients[1]
b = logMod$coefficients[2]
c = logMod$coefficients[3]
plot(x,y,cex=.3,col="blue")
curve(1/(1+exp(-(a+b*x+c*x^2))),from=-5,to=20,add=TRUE,col="red")
