
n=245 #antall kast fra hver distanse
k5=120 #totalt antall m??l fra 5 meter
k8=110 #totalt antall m??l fra 8 meter
k10_1=97 #antall m??l for f??rste skudd fra 10 meter
k10_2=92 #antall m??l for andre skudd fra 10 meter

#Posterior ved 5 meter
n=245
a1=120
b1=125
p5=a1/(a1+b1)

#Posterior ved 8 meter
n=245
a2=110
b2=135
p8=a2/(a2+b2)

#Posterior for f??rste skudd ved 10 meter
n=245
a3=97
b3=148
p10_1=a3/(a3+b3)

#Posterior for andre skudd ved 10 meter
n=245
a4=92
b4=153
p10_2=a4/(a4+b4)

#Posterior for totalt alle skudd ved 10 meter
n2=490
a5=a3+a4
b5=b3+b4
p10=a5/(a5+b5)