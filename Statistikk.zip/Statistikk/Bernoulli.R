a0=12
b0=8
x_unit = seq(0,1,0.001)
y_beta0 = dbeta(x_unit,a0,b0)
plot(x_unit,y_beta0,type="l",col="blue",ylim=c(0,12))
k1=28
l1=30
a1=a0+k1
b1=b0+l1
y_beta1 = dbeta(x_unit,a1,b1)
lines(x_unit,y_beta1,type="l",col="green")
k2=31
l2=19
a2=a1+k2
b2=b1+l2
y_beta2 = dbeta(x_unit,a2,b2)
lines(x_unit,y_beta2,type="l",col="maroon")

# Normaltilnærming til P0-beta
# Normaltilnærming til beta
m0 = a0/(a0+b0)
s0 = sqrt(a0*b0/((a0+b0)^2*(a0+b0+1)))
y_norm0 = dnorm(x_unit,m0,s0)
plot(x_unit,y_beta0,type="l",col="blue",ylim=c(0,5))
lines(x_unit,y_norm0,type="l",col="orange")
text(0.9,3.5,"betafordeling ß",col="blue",adj=1)
text(0.9,3.33,paste("(",a0,",",b0,")",sep=""),col="blue",adj=0)
text(0.3,3.5,"normalfordeling φ",col="orange",adj=1)
text(0.3,3.33,paste("(",round(m0,2),",",round(s0,2),")",sep=""),col="orange",adj=0)

