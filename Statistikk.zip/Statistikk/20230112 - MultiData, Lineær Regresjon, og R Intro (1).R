2+2
a=2+2
a
(b=3+4)

liste = c(1,2,3,5,7,11)
rekke = c(64,32,16,8,4,2)
liste
rekke

liste+rekke
liste*rekke
liste-rekke
liste/rekke
liste^rekke

ulik1 = c(1,2)
ulik2 = c(3,4,5)
ulik6 = c(11,12,13,14,15,16)

ulik1+ulik2
ulik1+ulik6
ulik2+ulik6

lik=c(ulik1,ulik2)
lik

(lavMatrise = rbind(liste,rekke)) # row bind
lavMatrise[2,4]
lavMatrise[2,]
lavMatrise[,4]

(hoyMatrise = cbind(liste,rekke)) # column bind
hoyMatrise[5,1]
(hoyDataRamme = as.data.frame(hoyMatrise))
hoyDataRamme$liste
hoyDataRamme[,1]
hoyDataRamme[4,]

plot(x=liste,y=rekke)
plot(x=liste,y=rekke,col="maroon")
plot(x=liste,y=rekke,col="maroon",type="h")
plot(x=liste,y=rekke,col="maroon",type="l")
plot(x=liste,y=rekke,col="maroon",type="s")
plot(x=liste,y=rekke,col="maroon",type="p")
plot(x=liste,y=rekke,col="maroon",type="p",pch=5)
plot(x=liste,y=rekke,col="maroon",type="p",cex=5)

liste2=c(3,7,9)
rekke2=c(42,11,23)
lines(x=liste2,y=rekke2,type="l",col="blue")  # Legger til på plott

plot(hoyDataRamme) # Forenklet
abline(v=6,col="green")
abline(h=50,col="pink")

?plot

# install.packages("car")
library(car)
scatterplot(x=liste,y=rekke)

5:9
seq(5,9)
seq(5,9,0.1)

sample(-100:50,5)
sample(82,7)

set.seed(314)
sample(82,7)


høyder2 = read.csv("Hoyde og arv2.csv", sep=";")
høyder = read.csv("Hoyde og arv.csv")
høyder

plot(høyder$Far,høyder$Egen)
scatterplot(høyder$Far,høyder$Egen)

# Kovarians
cov(liste,rekke)
cov(2*liste,rekke)
cov(2*liste,2*rekke)

# Korrelasjon
cor(liste,rekke)
cor(2*liste,rekke)
cor(2*liste,2*rekke)
cor(200*liste,200*rekke)
cor(-liste,rekke)

plot(liste,rekke)
linMod = lm(rekke ~ liste)
abline(linMod, col="maroon")

# Praktisk regning, med høyder.

x = høyder$Far
y = høyder$Egen

linearModel = lm(y ~ x)
modelSummary = summary(linearModel)
modelSummary

# Finne alfa og beta, altså linjen
modelSummary$coefficients[1:2]
alfa = modelSummary$coefficients[1]
beta = modelSummary$coefficients[2]
alfa
beta
plot(x,y,xlab="Fars høyde",ylab="Egen høyde",xlim=c(0,200),ylim=c(100,200))
abline(linearModel,col="maroon")

plot(x,y,xlab="Fars høyde",ylab="Egen høyde")
abline(linearModel,col="maroon")

modelSummary$sigma

# Regresjonslinje: y = 113.7104 + 0.3691075 * x

mineTall = sample(83,7)
mineTall

mineHøyder = høyder[mineTall,1:2]
mineHøyder

minModell = lm(Egen ~ Far, data=mineHøyder)
minSummary = summary(minModell)
minSummary

minAlfa = minSummary$coefficients[1]
minBeta = minSummary$coefficients[2]

abline(minModell,col="green")

plot(x=mineHøyder$Far, y=mineHøyder$Egen)
abline(minModell,col="green")

minX = mineHøyder$Far
minY = mineHøyder$Egen
minPredY = minAlfa + minX * minBeta 

segments(minX,minY,minX,minPredY,col="orange")
# Størrelsen på disse, er ...
minSummary$residuals
SSe = sum(minSummary$residuals^2)
sqrt(SSe/(7-2))
minSummary$sigma
