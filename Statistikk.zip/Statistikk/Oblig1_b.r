
col1 = c(15,20,25,30,30)
col2 = c(96,99,111,121,190)
table1 <- data.frame(col1, col2)

library(ggplot2)

  
regression_line <- lm(col2 ~ col1, data = table1)

plot(col1, col2, data = table1, xlab = 'Startposisjon', ylab = 'Sprettlengde')
abline(regression_line)

datasett = read.csv("/Users/00kriset/documents/UNI fag/statistikk/hoyde_lenge.csv")


ggplot(data=table1, aes(x=col1, y=col2))+ geom_point(size = 4, shape = 23, fill = 'darkcyan') +
  labs(title = 'Alle punktene', x = 'Startposisjon [cm]', y = 'Sprettlengde [cm]')
